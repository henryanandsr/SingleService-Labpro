export {default as Login} from './login/page';
export {default as Config} from './config/page';
export {default as Barang} from './barang/page';
export {default as Perusahaan} from './perusahaan/page';